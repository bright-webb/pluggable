<?php

namespace App\Plugin\Test;

use Tests\TestCase;

class RepoUnitTest extends TestCase
{
    public function test_that_this_is_true()
    {
        $this->assertTrue(true);
    }
}