<?php

namespace App\Plugin\Test;

use Tests\TestCase;

class HomeUnitTest extends TestCase
{
    public function test_that_this_is_true()
    {
        $this->assertTrue(true);
    }
}